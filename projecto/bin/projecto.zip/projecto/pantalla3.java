package projecto;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class pantalla3 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	private ArrayList<inicio> jugadores = new ArrayList<>();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pantalla3 frame = new pantalla3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public pantalla3() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 414, 240);
		contentPane.add(panel);
		panel.setLayout(null);

		JButton btnNewButton = new JButton("Añadir jugador");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nombre = textField.getText();
				String apellido = textField_1.getText();
				String dorsalStr = textField_2.getText();

				if (dorsalStr.isEmpty()) {
					System.out.println("Dorsal no puede estar vacío.");
					return;
				}

				int dorsal = Integer.parseInt(dorsalStr);
				inicio jugador = new inicio(nombre, apellido, dorsal);
				jugadores.add(jugador);

				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");

				System.out.println("Jugador añadido: " + jugador);
			}
		});
		btnNewButton.setBounds(282, 45, 122, 23);
		panel.add(btnNewButton);

		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setBounds(35, 49, 46, 14);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Apellido");
		lblNewLabel_1.setBounds(35, 93, 46, 14);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Dorsal");
		lblNewLabel_2.setBounds(35, 134, 46, 14);
		panel.add(lblNewLabel_2);

		JButton btnNewButton_1 = new JButton("Mostrar jugadores");
		btnNewButton_1.setBounds(282, 108, 122, 23);
		panel.add(btnNewButton_1);

		textField = new JTextField();
		textField.setBounds(110, 46, 86, 20);
		panel.add(textField);
		textField.setColumns(10);
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if (textField.getText().length() >= 20) {
					e.consume(); 
				}
			}
		});

		textField_1 = new JTextField();
		textField_1.setBounds(110, 90, 86, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if (textField_1.getText().length() >= 20) {
					e.consume(); 
				}
			}
		});

		textField_2 = new JTextField();
		textField_2.setBounds(110, 131, 86, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!Character.isDigit(c) || textField_2.getText().length() >= 3) {
					e.consume(); 
				}
			}
		});
	}
}
