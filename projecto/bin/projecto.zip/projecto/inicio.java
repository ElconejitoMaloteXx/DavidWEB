package projecto;

import javax.swing.JFrame;

public class inicio {
private String Nombre;
private String Apelido;
private int Dorsal;

	public inicio(String nombre, String apelido, int dorsal) {
		Nombre = nombre;
		Apelido = apelido;
		Dorsal = dorsal;
}
	@Override
	public String toString() {
		return "inicio [Nombre=" + Nombre + ", Apelido=" + Apelido + ", Dorsal=" + Dorsal + "]";
	}
	public static void main(String[] args) {
		JFrame p1 = new pantalla2();
		p1.setVisible(true);

	}

}
