package projecto;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class pantalla2 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pantalla2 frame = new pantalla2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pantalla2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		setBackground(new Color(255, 255, 128));
        getContentPane().setLayout(null);
        

        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 255, 128));
        panel.setBounds(0, 0, 430, 265);
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("Basket 3X3");
        lblNewLabel.setFont(new Font("Times New Roman", Font.ITALIC, 28));
        lblNewLabel.setForeground(new Color(128, 128, 128));
        lblNewLabel.setBounds(162, 11, 138, 52);
        panel.add(lblNewLabel);

        JButton btnNewButton = new JButton("Añadir jugador");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
            }
        });
        btnNewButton.setBounds(30, 74, 130, 23);
        panel.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Añadir equipo");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            }
        });
        btnNewButton_1.setBounds(290, 74, 130, 23);
        panel.add(btnNewButton_1);
        
        ImageIcon originalIcon = new ImageIcon("C:\\Users\\davmonbla\\eclipse-workspace\\projecto\\img\\basket.jpg");
        
        Image scaledImage = originalIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblImagen = new JLabel();
        lblImagen.setBounds(170, 74, 130, 127);
        lblImagen.setIcon(scaledIcon);
        panel.add(lblImagen);
        
        JButton torneos = new JButton("Añadir torneo");
        torneos.setBounds(170, 212, 110, 23);
        panel.add(torneos);
	}
}
